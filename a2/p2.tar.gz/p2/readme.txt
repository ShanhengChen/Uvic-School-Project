the program ACS takes .txt input and performs a task scheduler 
you should enter make command to make a ACS file first 
then enter ./ACS input2.txt or ./ACS (something else).txt

if you enter a wrong format of date or a wrong file the program will end

I design a customer.txt for marker to test
enter make then ./ACS customer.txt